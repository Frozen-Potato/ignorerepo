"""The pyang library for parsing, validating, and converting YANG modules"""

__version__ = '2.6.1'
__date__ = '2024-05-23'
